package edu.kosmo.ex.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j;

@Log4j
@Component   // 컴포넌트는 service, controller 부모
@Aspect		 // 관점지향 선언
public class LogAdvice {
	
	@Before("within(edu.kosmo.ex.service.*)")
	public void logBefore() {
		System.out.println("공통기능 - 로그비포====================================");
	}
	
	@After("within(edu.kosmo.ex.service.*)")
	public void logAfter() {
		System.out.println("공통기능 - 로그애프터***********************************");
	}
	
	@Around("within(edu.kosmo.ex.service.*)") // 적용 시켜 줄 함수
	   public Object loggerAop(ProceedingJoinPoint joinpoint) throws Throwable {
	      
	      String signatureStr = joinpoint.getSignature().toShortString(); // 실행하고 있는 함수를 호출
	      
	      System.out.println( signatureStr + " is start.");
	      
	      long st = System.currentTimeMillis(); // 시작 시간 // before
	      
	      try {
	         Object obj = joinpoint.proceed();  // 여기서 끌고오는 함수를 실행 // 여길 기준으로 위 전/ 아래 후
	         
	         return obj;
	      } finally {
	      
	         long et = System.currentTimeMillis(); // 끝나는 시간 // after
	         
	         System.out.println( signatureStr + " is finished.");
	         System.out.println( signatureStr + " 경과시간 : " + (et - st));
	      }      
	   }
	
}
