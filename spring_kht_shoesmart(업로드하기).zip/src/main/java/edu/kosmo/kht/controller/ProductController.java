package edu.kosmo.kht.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import edu.kosmo.kht.service.ProductService;
import edu.kosmo.kht.vo.BoardVO;
import edu.kosmo.kht.vo.ProductVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Log4j
@AllArgsConstructor
@Controller
public class ProductController {
	
	@Inject
	private ProductService productService;
	
	@GetMapping("/productlist")
	public String list(Model model) {
		
		System.out.println("list()..");
		model.addAttribute("productList", productService.getList());
		
		return "product/productlist";
	}
	
	@GetMapping("/product_write_view")
	public String write_view(Model model) {
		
		System.out.println("product_write_view() ...");	
		
		return "product/product_write_view";
	}
	/*
	@PostMapping("/pwrite")
	public String write(ProductVO productVO) {
		
		System.out.println("pwrite() ...");	
		
		productService.pwrite(productVO);
		
		return "redirect:list";
	}
	
	@PostMapping("/pwrite")
	public String pwrite(ProductVO productVO) throws IOException { 
				// 파일 업로드 처리
				String fileName=null;
				MultipartFile uploadFile = productVO.getUploadFile();
				if (!uploadFile.isEmpty()) {
					String originalFileName = uploadFile.getOriginalFilename();
					String ext = FilenameUtils.getExtension(originalFileName);	//확장자 구하기
					UUID uuid = UUID.randomUUID();	//UUID 구하기
					fileName=uuid+"."+ext;
					uploadFile.transferTo(new File("D:\\upload\\" + fileName));
				}
				productVO.setFileName(fileName);
				productService.pwrite(productVO); 
				return "redirect:productlist"; 
		}
	*/
	
	

	
}
