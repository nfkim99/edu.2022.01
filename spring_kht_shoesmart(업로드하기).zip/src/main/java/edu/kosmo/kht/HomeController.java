package edu.kosmo.kht;

import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import edu.kosmo.kht.HomeController;
import edu.kosmo.kht.service.BoardService;
import edu.kosmo.kht.service.ProductService;
import edu.kosmo.kht.vo.BoardVO;
import edu.kosmo.kht.vo.ProductVO;
import lombok.extern.log4j.Log4j;


@Log4j
@Controller
public class HomeController {
	
	@Inject
	private BoardService boardService;
	
	@Inject
	private ProductService productService;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	
	@GetMapping("/user/userHome")
	public void userHome() {
		logger.info("userHome ...");

	}
	
	@GetMapping("/user/board/list")
	public String userBoardList(Model model) {
		
		System.out.println("list()..");
		model.addAttribute("boardList", boardService.getList());
		
		return "board/list";

	}
	
	@GetMapping("/product/productlist")
	public String ProductList(Model model) {
		
		System.out.println("ProductList()..");
		model.addAttribute("productList", productService.getList());
		
		return "product/productlist";

	}
	
	@GetMapping("/admin/product/productlist")
	public String adminProductList(Model model) {
		
		System.out.println("ProductList()..");
		model.addAttribute("productList", productService.getList());
		
		return "product/productlist";

	}
	
	@GetMapping("/product/product_write_view")
	public String product_write_view(Model model) {
		logger.info("product_write_view ...");
		
		System.out.println("product_write_view() ...");	
		
		return "product/product_write_view";

	}
	
	@PostMapping("/product/pwrite")
	public String pwrite(ProductVO productVO) {
		
		System.out.println("pwrite() ...");	
		
		productService.pwrite(productVO);
		
		return "redirect:productlist";
	}
	
	
	@GetMapping("/user/board/write_view")
	public String userWrite_view(Model model) {
		logger.info("userWrite_view ...");
		
		System.out.println("write_view() ...");	
		
		return "board/write_view";

	}
	
	@PostMapping("/user/board/write")
	public String userWrite(BoardVO boardVO) {
		
		System.out.println("write() 글쓰기 ...");	
		
		boardService.write(boardVO);
		
		return "redirect:list";

	}
	
	@GetMapping("/user/package")
	public void userPackage() {
		logger.info("userPackage ...");

	}
	
	@GetMapping("/admin/adminHome")
	public void adminHome() {
		logger.info("adminHome ...");

	}
	
	
	@GetMapping("/login/loginForm")
	public String loginForm() {
		System.out.println("Welcome Login Form");
		return "login/loginForm2";
	}
	
	/*
	@RequestMapping(value = "/loginInfo", method = RequestMethod.GET)
	   public String loginInfo(Principal principal,Model model) { //Principal객체를 받아올 수 있음
	      
	      //1.Controller를 통하여 Pincipal객체로 가져오는 방법
	      String user_id = principal.getName();
	      System.out.println("유저 아이디:" + user_id   );
	      
	      //2.SpringContextHolder를 통하여 가져오는 방법(일반적인 빈에서 사용 할수있음 )
	      Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	        user_id = auth.getName();
	        System.out.println("유저 아이디:" + user_id   );
	        
	        //3.
	        UserDetails userDetails = (UserDetails) auth.getPrincipal();
	        System.out.println(userDetails.getUsername());

	        //4.
	        //CustomUserDetails couCustomUserDetails =  (CustomUserDetails) auth.getPrincipal();
	        //System.out.println(couCustomUserDetails.getEmp());
	        
	       //5.User 클래스로 변환 하여 가져오는 방법
	        //couCustomUserDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	        //user_id = couCustomUserDetails.getUsername();
	        //System.out.println("유저 아이디:" + user_id   );
	        
	        return "home";
	   }
	   */
	
}
