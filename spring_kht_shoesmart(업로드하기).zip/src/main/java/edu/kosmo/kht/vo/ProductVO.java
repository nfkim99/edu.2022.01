package edu.kosmo.kht.vo;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.log4j.Log4j;

/*
 * 
productid number primary key,
productname varchar2(100)   not null,
categorycode varchar2(30),
productprice number not null,
productstock number not null,
productdiscount number(2,2),
productsize number,
productimage varchar2(120),
regDate date default sysdate

 */

@Log4j
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ProductVO {
	
	private int productid;
	private String productname;
	private String categorycode;
	private int productprice;
	private int productstock;
	private int productdiscount;
	private int productsize;
	private String productimage;
	private Timestamp regdate;
	
	private String fileName;
	private MultipartFile uploadFile;
	
}
