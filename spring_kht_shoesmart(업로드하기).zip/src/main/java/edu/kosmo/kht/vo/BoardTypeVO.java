package edu.kosmo.kht.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class BoardTypeVO {
	
	/*
	 * 		TYPEID		NUMBER
			BOARDNAME	VARCHAR2(100 BYTE)
	 * 
	 */
	private String typeid;
	private String boardname;
	
}
