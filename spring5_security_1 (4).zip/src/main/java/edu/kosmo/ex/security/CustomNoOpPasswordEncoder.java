package edu.kosmo.ex.security;



import org.springframework.security.crypto.password.PasswordEncoder;

import lombok.extern.log4j.Log4j;

@Log4j
public class CustomNoOpPasswordEncoder implements PasswordEncoder {

	public String encode(CharSequence rawPassword) {

		System.out.println(rawPassword);
		return rawPassword.toString();
	}

	public boolean matches(CharSequence rawPassword, String encodedPassword) {

		System.out.println(rawPassword + ":" + encodedPassword);

		return rawPassword.toString().equals(encodedPassword);
	}

}