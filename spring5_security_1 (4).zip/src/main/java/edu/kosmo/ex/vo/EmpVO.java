package edu.kosmo.ex.vo;

import java.sql.Timestamp;

import lombok.extern.log4j.Log4j;

@Log4j
public class EmpVO {
	int empno;    //NOT NULL NUMBER(4)    
	String ename; //             VARCHAR2(10) 
	String job;//               VARCHAR2(9)  
	int mgr;//               NUMBER(4)    
	Timestamp hiredate;//          DATE         
	int sal;//               NUMBER(7,2)  
	int comm;//              NUMBER(7,2)  
	int deptno;//            NUMBER(2)  
	
	public EmpVO() {

	}
	
	public EmpVO(int empno, String ename, String job, int mgr, Timestamp hiredate, int sal, int comm, int deptno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.job = job;
		this.mgr = mgr;
		this.hiredate = hiredate;
		this.sal = sal;
		this.comm = comm;
		this.deptno = deptno;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getMgr() {
		return mgr;
	}
	public void setMgr(int mgr) {
		this.mgr = mgr;
	}
	public Timestamp getHiredate() {
		return hiredate;
	}
	public void setHiredate(Timestamp hiredate) {
		this.hiredate = hiredate;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public int getComm() {
		return comm;
	}
	public void setComm(int comm) {
		this.comm = comm;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	
	
	
	
	
}