package edu.kosmo.kht.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import edu.kosmo.kht.service.ProductService;
import edu.kosmo.kht.vo.BoardVO;
import edu.kosmo.kht.vo.ProductVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Log4j
@AllArgsConstructor
@Controller
@SessionAttributes("product")
public class ProductController {

	@Inject
	private ProductService productService;

	
	@GetMapping("/product/productlist")
	public String list(Model model) {

		System.out.println("list()..");
		model.addAttribute("productList", productService.getList());

		return "product/productlist";
	}

	@GetMapping("/product/product_write_view")
	public String write_view(Model model) {

		System.out.println("product_write_view() ...");

		return "product/product_write_view";
	}

	
	@RequestMapping("/product/pwrite")
	public String pwrite(ProductVO productVO) throws IOException {
		
		System.out.println("이제 pwrite 탄다 ㅅㅂ!!() ...");
		// 파일 업로드 처리
		String fileName = null;
		MultipartFile uploadFile = productVO.getUploadFile();
		System.out.println("여기까오는거확인() ...");
		System.out.println(uploadFile);
		if (!uploadFile.isEmpty()) {
			System.out.println("여기 if탐?() ...");
			String originalFileName = uploadFile.getOriginalFilename();
			String ext = FilenameUtils.getExtension(originalFileName); // 확장자 구하기
			UUID uuid = UUID.randomUUID(); // UUID 구하기
			fileName = uuid + "." + ext;
			uploadFile.transferTo(new File("D:\\upload\\" + fileName));
			
		}
		productVO.setFileName(fileName);
		productService.pwrite(productVO);
		return "redirect:productlist";
	}
	

	/*
	 * @PostMapping("/pwrite") public String write(ProductVO productVO) {
	 * 
	 * System.out.println("pwrite() ...");
	 * 
	 * productService.pwrite(productVO);
	 * 
	 * return "redirect:list"; }
	 * 
	 * 
	 */

}
