package edu.kosmo.kht.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


@Controller
public class UploadController {
	/*
		private static final String FILE_PATH = "C:\\Users\\kosmo\\Documents\\tomcat\\apache-tomcat-9.0.55-windows-x64\\apache-tomcat-9.0.55\\wtpwebapps\\spring_kht_shoesmart";
		
		@RequestMapping(value = "upload", method = RequestMethod.GET)
		public String link() {
			return "board";
		}
		
		
		@RequestMapping(value = "upload", method = RequestMethod.POST)
		public String upload(@RequestParam("uploadFile")MultipartFile file,
				     Model model) throws IllegalStateException, IOException {
			String fileName = file.getOriginalFilename();
			
			if(!file.getOriginalFilename().isEmpty()) {
				file.transferTo(new File(FILE_PATH, fileName));
				model.addAttribute("msg", "File uploaded successfully.");
				model.addAttribute("fileName", fileName);
			}else {
				model.addAttribute("msg", "Please select a valid mediaFile..");
			}
			
			return "board";
		}
	}
	
	private static final String FILE_PATH = "업로드될 경로 지정";
	
	@RequestMapping(value = "upload", method = RequestMethod.GET)
	public String link() {
		return "board";
	}
	
	
	@RequestMapping(value = "upload", method = RequestMethod.POST)
	public String upload(@RequestParam("uploadFile")MultipartFile file,
			     Model model) throws IllegalStateException, IOException {
		String fileName = file.getOriginalFilename();
		
		if(!file.getOriginalFilename().isEmpty()) {
			file.transferTo(new File(FILE_PATH, fileName));
			model.addAttribute("msg", "File uploaded successfully.");
			model.addAttribute("fileName", fileName);
		}else {
			model.addAttribute("msg", "Please select a valid mediaFile..");
		}
		
		return "board";
	}

*/
}