package edu.kosmo.kht.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.kosmo.ex.page.Criteria;
import edu.kosmo.kht.mapper.BoardMapper;
import edu.kosmo.kht.mapper.ProductMapper;
import edu.kosmo.kht.vo.BoardVO;
import edu.kosmo.kht.vo.ProductVO;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductMapper productMapper;
	

	@Override
	public List<ProductVO> getList() {
		
		System.out.println("getList() .. 리스트탄당~");
		
		return productMapper.getList();
	}

	@Override
	public ProductVO get(int productid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pwrite(ProductVO productVO) {
		
		System.out.println("productinsert() .. 상품등록 탄당~");	
		productMapper.productInsert(productVO);
		
	}

	@Override
	public void delete(int productid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(ProductVO product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void upHit(int productid) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
}
