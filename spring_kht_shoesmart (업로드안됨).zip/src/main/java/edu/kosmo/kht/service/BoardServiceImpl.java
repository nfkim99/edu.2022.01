package edu.kosmo.kht.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.kosmo.ex.page.Criteria;
import edu.kosmo.kht.mapper.BoardMapper;
import edu.kosmo.kht.vo.BoardVO;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardMapper boardMapper;
	
	@Override
	public List<BoardVO> getList() {
		
		System.out.println("getList() .. 리스트탄당~");
		
		return boardMapper.getList();
	}

	@Override
	public BoardVO get(int bid) {
		
		System.out.println("getContent() .. 컨텐트탄당~");
		upHit(bid);
		return boardMapper.read(bid);
	}

	@Override
	public void write(BoardVO board) {
		
		System.out.println("write() .. 글작성 탄당~");	
		boardMapper.insert(board);
	}

	@Override
	public void delete(int bid) {
		
		System.out.println("delete() .. 글삭제 탄당~");	
		boardMapper.delete(bid);
		
	}

	@Override
	public void update(BoardVO board) {
		
		System.out.println("update() .. 수정하기 탄당~");	
		boardMapper.update(board);
		
	}


	@Transactional // @Transactional 쓰는 이유 - insert , update 작업이 2개 이상이므로 사용.
	@Override
	public void insertReply(BoardVO board) {
		
		boardMapper.replyShape(board); // 업데이트 성공
		
		boardMapper.insertReply(board); // 만약에, 에러가 나면 위의 replyShape는 롤백 원복시켜줘야함 - @Transactional 쓰는 이유
		
	}

	@Override
	public void upHit(int bid) {
		System.out.println("upHit() .. 조회수 탄당~");	
		boardMapper.updateHit(bid);
		
	}

	@Override
	public int getTotal() {
		
		System.out.println("getTotal() .. 갯수 탄당~");	
		return boardMapper.getTotalCount();
	}

	@Override
	public List<BoardVO> getList(Criteria criteria) {
		
		System.out.println("getList() ... 페이징리스트 탄당~");	
		return boardMapper.getListWithPaging(criteria);
	}
	
	
	
}
