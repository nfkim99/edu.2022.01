package edu.kosmo.kht.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import edu.kosmo.kht.vo.UserVO;

@Mapper
public interface UserMapper {
	
   
   public UserVO getUser(String userid); // xml로 처리하겟다 = UserMapper.xml에 있음
   
   @Insert("insert into member(userid,password,name,age,job,grade,mileage) values(#{userid},#{password},#{name},#{age},#{job},#{grade},#{mileage})")
   public int insertUser(UserVO userVO);

   @Insert("insert into AUTHORITIES (userid,AUTHORITY) values(#{userid},'ROLE_USER')")
   public void insertAuthorities(UserVO UserVO);

   
}