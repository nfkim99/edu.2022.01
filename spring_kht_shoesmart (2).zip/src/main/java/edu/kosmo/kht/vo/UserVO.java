package edu.kosmo.kht.vo;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.log4j.Log4j;

@Log4j
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserVO {
	
	/*
	 * 	USERID		VARCHAR2(20 BYTE)
		PASSWORD	VARCHAR2(20 BYTE)
		NAME		VARCHAR2(20 BYTE)
		AGE			NUMBER
		JOB			VARCHAR2(20 BYTE)
		GRADE		NUMBER
		MILEAGE		NUMBER
		
	 */

	
   private String userid;
   private String password;
   private String name;
   private int age;
   private String job;
   private int grade;
   private int mileage;
   
   private List<AuthVO> authList;
   
   
}