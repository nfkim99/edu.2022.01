package edu.kosmo.kht.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import edu.kosmo.ex.page.Criteria;
import edu.kosmo.ex.page.PageVO;
import edu.kosmo.kht.service.BoardService;
import edu.kosmo.kht.vo.BoardVO;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Log4j
@AllArgsConstructor
@Controller
public class BoardController {
	
	@Inject
	private BoardService boardService;
	
	@GetMapping("/list")
	public String list(Model model) {
		
		System.out.println("list()..");
		model.addAttribute("boardList", boardService.getList());
		
		return "board/list";
	}
	
	// http://localhost:8282/ex/content_view?bid=85
	
	@GetMapping("/content_view")
	public String content_view(BoardVO boardVO, Model model) {
		
		System.out.println("content_view() ...");
		System.out.println("BoardVO.." + boardVO);
		
		int bid = boardVO.getBid();
		
		model.addAttribute("content_view", boardService.get(bid));
		
		return "board/content_view";
	}
	
	
	@GetMapping("/write_view")
	public String write_view(Model model) {
		
		System.out.println("write_view() ...");	
		
		return "board/write_view";
	}
	
	@PostMapping("/write")
	public String write(BoardVO boardVO) {
		
		System.out.println("write() ...");	
		
		boardService.write(boardVO);
		
		return "redirect:list";
	}
	
	@GetMapping("/delete")
	public String delete(int bid) {
		
		System.out.println("delete() ...");	
		
		boardService.delete(bid);
		
		return "redirect:list";
	}
	
	@GetMapping("/reply_view")
	public String reply_view(BoardVO boardVO, Model model) {
		
		System.out.println("reply_view() ... 답변 탄다~!~");	
		
		model.addAttribute("reply_view", boardService.get(boardVO.getBid()));
		
		return "board/reply_view";
	}
	
	@PostMapping("/reply")
	public String reply(BoardVO boardVO) {
		
		System.out.println("reply() ...");	
		
		boardService.insertReply(boardVO);
		
		return "redirect:list";
	}
	
	@GetMapping("/list2")
	public String list2(Criteria cri, Model model) {
		
		System.out.println("list2()..");
		System.out.println("Criteria : " + cri);
		
		model.addAttribute("boardList", boardService.getList(cri));
		int total = boardService.getTotal();
		
		System.out.println("total : " + total);	
		model.addAttribute("pageMaker", new PageVO(cri, total));
		
		return "board/list2";
	}
	
	@GetMapping("/list3")
	public String list3(Model model) {
		
		System.out.println("list()..");
		model.addAttribute("boardList", boardService.getList());
		
		return "board/tables";
	}
	
	

}
