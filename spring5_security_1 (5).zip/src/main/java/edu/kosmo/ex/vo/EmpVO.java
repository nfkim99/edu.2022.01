package edu.kosmo.ex.vo;

import java.sql.Timestamp;
import java.util.List;

import lombok.extern.log4j.Log4j;

@Log4j
public class EmpVO {
	private int empno;    //NOT NULL NUMBER(4)    
	private String ename; //             VARCHAR2(10) 
	private String job;//               VARCHAR2(9)  
	private int mgr;//               NUMBER(4)    
	private Timestamp hiredate;//          DATE         
	private int sal;//               NUMBER(7,2)  
	private int comm;//              NUMBER(7,2)  
	private int deptno;//            NUMBER(2)  
	
	private List<AuthVO> AuthList;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgr() {
		return mgr;
	}

	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	public Timestamp getHiredate() {
		return hiredate;
	}

	public void setHiredate(Timestamp hiredate) {
		this.hiredate = hiredate;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public int getComm() {
		return comm;
	}

	public void setComm(int comm) {
		this.comm = comm;
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public List<AuthVO> getAuthList() {
		return AuthList;
	}

	public void setAuthList(List<AuthVO> authList) {
		AuthList = authList;
	}

	public static org.apache.log4j.Logger getLog() {
		return log;
	}
	
}